<x-app-layout>
    <section>
        <h1>Dashboard</h1>
    </section>
</x-app-layout>
